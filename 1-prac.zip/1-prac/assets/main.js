'use strict';

let name = prompt ("Ваше Имя");
let Surname = prompt ("Ваша фамилия");
let Pastname = prompt ("Ваше отчество");
 
let istrue = confirm (`${name} ${Surname} ${Pastname}`);

alert (istrue);